package com.nissan.app;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "service2", url = "http://localhost:8082")
public interface ProfileClientService {

	@GetMapping("/api/profile/getProfile")
	String getProfile();
}
