package com.nissan.app.service;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@RestController
@RequestMapping("/api/profile/")
public class UserProfileRest {

	@GetMapping("/getProfile")
	public String getMethodName() {
		return new String("service2 invoked successfully");
	}
	
}
