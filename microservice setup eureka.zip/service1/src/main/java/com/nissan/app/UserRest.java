package com.nissan.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.CircuitBreaker;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/payment")
public class UserRest {

	@Autowired
	private ProfileClientService clientService;

	@Autowired
	private CircuitBreakerFactory breakerFactory;

	private static final String SERVICE_NAME = "service2";

	@GetMapping("/call-service-2")
	public String getMethodName() {
		CircuitBreaker bb = breakerFactory.create(SERVICE_NAME);
		return bb.run(() -> clientService.getProfile(), throwable -> fallbackMethod());
	}

	private String fallbackMethod() {
		return new String("Fallback response: Service B is currently unavailable. Please try again later.");
	}

}
