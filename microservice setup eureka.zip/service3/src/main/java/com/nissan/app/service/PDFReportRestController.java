package com.nissan.app.service;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/pdf")
public class PDFReportRestController {

	@GetMapping("/report")
	public String getMethodName() {
		return new String("pdf service invoked successfully");
	}
}
