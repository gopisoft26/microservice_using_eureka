package com.nissan.gateway.app.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewayAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
